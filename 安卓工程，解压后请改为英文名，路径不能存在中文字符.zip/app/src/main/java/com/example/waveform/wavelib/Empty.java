package com.example.waveform.wavelib;

public class Empty {
}
