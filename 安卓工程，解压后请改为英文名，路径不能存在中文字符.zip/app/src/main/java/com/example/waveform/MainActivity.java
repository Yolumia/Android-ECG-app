package com.example.waveform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;

import com.example.waveform.wavelib.utils.WaveUtil;
import com.example.waveform.wavelib.view.WaveView;

import java.util.Random;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private WaveUtil  waveUtil2;

    private WaveView wave_view2;//显示波形的控件，

    private SeekBar seekBar;//调节速度的滑块


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        waveUtil2 = new WaveUtil();


        wave_view2 = findViewById(R.id.wave_view2);
        seekBar = findViewById(R.id.seek_bar);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Log.i("seek_bar progress is", i + "");
                if (i == 0)
                    return;

                wave_view2.setWaveLineWidth(i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        waveUtil2.showWaveDatas(1, wave_view2);
        Log.e("通过类Data获取值",Data.getA()+"");

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        waveUtil2.stop();
    }
}