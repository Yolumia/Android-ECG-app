package com.example.waveform;
public class Data{
    private static float a = 0f;

    public static float getA() {
        return a;
    }

    public static void setA(float a) {
        Data.a = a;
    }
}