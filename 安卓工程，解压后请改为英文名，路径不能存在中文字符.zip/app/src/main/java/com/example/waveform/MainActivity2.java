package com.example.waveform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.waveform.wavelib.utils.WaveUtil;
import com.example.waveform.wavelib.view.WaveView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity2 extends AppCompatActivity {

    private WaveUtil waveUtil1, waveUtil2;

    private WaveView wave_view1, wave_view2;

    private SeekBar seekBar;

    /**
     * 保存已绘制的数据坐标
     */
    private float[] dataArray;

    //    float data = 0f;

    private static final int REQUEST_ENABLE_BT = 1;
    public String val;
    public float valint = 0f;
    private TextView txtIsConnected;
    private EditText edtReceivedMessage;
    private EditText edtSentMessage;
    private EditText edtSendMessage;
    private Button btnSend;
    private Button btnPairedDevices;

    private BluetoothAdapter mBluetoothAdapter;
    private ConnectedThread mConnectedThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        Button btn = (Button) findViewById(R.id.btnshowline);
        btn .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this , MainActivity.class);
                startActivity(i);
            }
        });



        txtIsConnected = (TextView) findViewById(R.id.txtIsConnected);
        edtReceivedMessage = (EditText) findViewById(R.id.edtReceivedMessage);
        edtSentMessage = (EditText) findViewById(R.id.edtSentMessage);
        edtSendMessage = (EditText) findViewById(R.id.edtSendMessage);
        btnSend = (Button) findViewById(R.id.btnSend);
        btnPairedDevices = (Button) findViewById(R.id.btnPairedDevices);

        btnPairedDevices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // 获取蓝牙适配器
                mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                if (mBluetoothAdapter == null) {
                    Toast.makeText(getApplicationContext(), "该设备不支持蓝牙", Toast.LENGTH_SHORT).show();
                }

                //请求开启蓝牙
                if (!mBluetoothAdapter.isEnabled()) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                }

                //进入蓝牙设备连接界面
                Intent intent = new Intent();
                intent.setClass(getApplicationContext(), DevicesListActivity.class);
                startActivity(intent);

            }
        });

        //点击【发送】按钮后，将文本框中的文本按照ASCII码发送到已连接的蓝牙设备
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtSendMessage.getText().toString().isEmpty()) {
                    return;
                }
                String sendStr = edtSendMessage.getText().toString();
                char[] chars = sendStr.toCharArray();
                byte[] bytes = new byte[chars.length];
                for (int i=0; i < chars.length; i++) {
                    bytes[i] = (byte) chars[i];
                }
                edtSentMessage.append(sendStr);
                mConnectedThread.write(bytes);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        //回到主界面后检查是否已成功连接蓝牙设备
        if (BluetoothUtils.getBluetoothSocket() == null || mConnectedThread != null) {
            txtIsConnected.setText("未连接");
            return;
        }

        txtIsConnected.setText("已连接");

        //已连接蓝牙设备，则接收数据，并显示到接收区文本框
        Handler handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case ConnectedThread.MESSAGE_READ:
                        byte[] buffer = (byte[]) msg.obj;
                        int length1 = msg.arg1;
                        edtSendMessage.setText(" ");

                        for (int i=0; i < length1; i++) {
                            char c = (char) buffer[i];
                            //edtReceivedMessage.getText().append(c);
                            edtSendMessage.getText().append(c);
                        }
                        val = edtSendMessage.getText().toString();
                        if(val.indexOf(':')!=-1&&val.indexOf('_')!=-1&&val.indexOf(':')<val.indexOf('_'))
                        {
                            //Toast.makeText(getApplicationContext(), val.substring(val.indexOf(':')+1,val.indexOf('_')), Toast.LENGTH_SHORT).show();
                            valint= Float.parseFloat(val.substring(val.indexOf(':')+1,val.indexOf('_')));
                            edtReceivedMessage.setText(valint+" v");
                            valint=(valint/3.3f)*20f-10f;
                            Data.setA(valint);

                        }

                        break;
                }

            }
        };

        //启动蓝牙数据收发线程
        mConnectedThread = new ConnectedThread(BluetoothUtils.getBluetoothSocket(), handler);
        mConnectedThread.start();

    }
}